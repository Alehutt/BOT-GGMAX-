const { 
    ApplicationCommandType, 
    EmbedBuilder, 
    ActionRowBuilder, 
    ButtonBuilder, 
    ApplicationCommandOptionType 
} = require("discord.js");

const { bot, db, perm } = require("../../database/index");

module.exports = {
    name: "update",
    description: "[🛠|💰 Vendas Moderação] Atualiza a mensagem de compra do produto",
    type: ApplicationCommandType.ChatInput,
    options: [
        {
            name: "id",
            description: "Coloque o ID do produto que será atualizado!",
            type: ApplicationCommandOptionType.String,
            required: true,
            autocomplete: true,
        }
    ],

    async autocomplete(interaction) {
        const value = interaction.options.getFocused().toLowerCase();
        const choices = db.all();

        const filtered = choices
            .filter(choice => choice.ID.toLowerCase().includes(value))
            .slice(0, 25);

        if (!await perm.get(`${interaction.user.id}`)) {
            return interaction.respond([
                { name: "Você não tem permissão para usar esse comando!", value: "sem_permissao" }
            ]);
        } else if (choices.length === 0) {
            return interaction.respond([
                { name: "Você não tem nenhum produto criado!", value: "sem_produtos" }
            ]);
        } else if (filtered.length === 0) {
            return interaction.respond([
                { name: "Não encontrei esse produto", value: "produto_nao_encontrado" }
            ]);
        } else {
            return interaction.respond(
                filtered.map(choice => ({ 
                    name: `ID - ${choice.ID} | Nome - ${choice.data.nome}`, 
                    value: choice.ID 
                }))
            );
        }
    },

    run: async (client, interaction) => {
        const id = interaction.options.getString("id");

        if (!await perm.get(`${interaction.user.id}`)) {
            return interaction.reply({
                embeds: [
                    new EmbedBuilder()
                        .setDescription(`⚠️ | Você não possui permissão para utilizar este comando!`)
                        .setColor("Red")
                ],
                ephemeral: true
            });
        }

        const prod = await db.get(id);
        if (!prod) {
            return interaction.reply({ 
                content: `🔍 | Produto inexistente`, 
                ephemeral: true 
            });
        }

        await interaction.reply({ content: `🔁 | Aguarde um momento...`, ephemeral: true });

        const embed = new EmbedBuilder().setColor(prod.cor);
        const channel = interaction.guild.channels.cache.get(prod.mensagem.channel);

        try {
            let title = await bot.get("mensagem_compra.titulo");
            title = title.replace("#{nome}", prod.nome)
                         .replace("#{preco}", Number(prod.preco).toFixed(2))
                         .replace("#{estoque}", prod.conta.length);
            embed.setTitle(title);

            let desc = await bot.get("mensagem_compra.desc");
            desc = desc.replace("#{nome}", prod.nome)
                       .replace("#{preco}", Number(prod.preco).toFixed(2))
                       .replace("#{estoque}", prod.conta.length)
                       .replace("#{desc}", prod.desc);
            embed.setDescription(desc);

            if (prod.banner?.startsWith("https://")) {
                embed.setImage(prod.banner);
            }
            if (prod.miniatura?.startsWith("https://")) {
                embed.setThumbnail(prod.miniatura);
            }

            const mensagem_compra = await bot.get("mensagem_compra");
            if (mensagem_compra.rodape !== "Sem Rodapé") {
                embed.setFooter({ text: mensagem_compra.rodape });
            }

            // Excluir mensagem anterior, se existir
            if (channel) {
                try {
                    const msg = await channel.messages.fetch(prod.mensagem.msgid);
                    if (msg) {
                        await msg.edit({ embeds: [embed] }); // Atualiza a mensagem
                    }
                } catch (error) {
                    console.log(`Erro ao atualizar mensagem (${prod.mensagem.msgid}):`, error.message);
                }
            }

            // Construção dos botões
            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId(`${id}_produto`)
                    .setLabel(mensagem_compra.button.text)
                    .setStyle(Number(mensagem_compra.button.style))
                    .setEmoji(mensagem_compra.button.emoji)
            );

            const duvidas = await bot.get("duvidas");
            if (duvidas.status) {
                const duvidasChannel = interaction.guild.channels.cache.get(duvidas.channel);
                if (duvidasChannel) {
                    row.addComponents(
                        new ButtonBuilder()
                            .setStyle(5)
                            .setLabel(duvidas.label)
                            .setEmoji(duvidas.emoji)
                            .setURL(duvidasChannel.url)
                    );
                }
            }

            // Atualizar ou adicionar os componentes
            await channel.messages.fetch(prod.mensagem.msgid)
                .then(msg => msg.edit({ embeds: [embed], components: [row] }))
                .catch(err => console.error(`Erro ao editar a mensagem: ${err.message}`));

            await interaction.editReply({ content: "✅ | Produto atualizado com sucesso!" });

        } catch (err) {
            console.error(`Erro ao atualizar produto:`, err);
            await interaction.editReply({
                content: `⚠️ | Ocorreu um erro ao tentar atualizar a mensagem\n\nErro: ${err.message}`,
                ephemeral: true
            });
        }
    }
};