const fs = require('fs');

module.exports = {
    run: (client) => {
        // Lê a pasta de eventos
        fs.readdirSync('./events/').forEach(folder => {
            const arquivosEvent = fs.readdirSync(`./events/${folder}`).filter(archive => archive.endsWith('.js'));

            // Registra cada evento encontrado
            for (const arquivo of arquivosEvent) {
                try {
                    const evento = require(`../events/${folder}/${arquivo}`);
                    if (evento.once) {
                        // Se o evento deve ser executado uma única vez
                        client.once(evento.name, (...args) => evento.run(...args, client));
                    } else {
                        // Se o evento deve ser executado sempre que ocorrer
                        client.on(evento.name, (...args) => evento.run(...args, client));
                    }
                } catch (error) {
                    console.error(`Erro ao carregar o evento ${arquivo}:`, error);
                }
            }
        });
    }
};