const { Client, GatewayIntentBits, Collection, Partials } = require("discord.js");
const { JsonDatabase } = require("wio.db");
console.clear();

const client = new Client({
    intents: Object.values(GatewayIntentBits),
    partials: Object.values(Partials)
});

// Aumenta o limite de ouvintes para 20
client.setMaxListeners(20);

module.exports = client;

client.on("messageCreate", async (message) => {
    const channel = "1137093737584013342"; // ID do canal específico
    const emoji = message.guild.emojis.cache.find(emoji => emoji.name === "saheart");
    if (message.channel.id === channel && emoji) {
        message.react(emoji);
    }
});

client.slashCommands = new Collection();
const { token } = require("./token.json");

client.login(token);

const evento = require("./handler/Events");
evento.run(client); // evento da cloud 

require("./handler/index")(client);

process.on('unhandledRejection', (reason, promise) => {
    console.log(`🚫 Erro Detectado:\n\n` + reason, promise);
});

process.on('uncaughtException', (error, origin) => {
    console.log(`🚫 Erro Detectado:\n\n` + error, origin);
});