const fs = require("fs");
const axios = require("axios");

module.exports = async (client) => {
    const SlashsArray = [];

    // Lê as pastas de comandos
    fs.readdir(`./commands`, (error, folders) => {
        if (error) return console.error("Erro ao ler as pastas de comandos:", error);

        folders.forEach(subfolder => {
            fs.readdir(`./commands/${subfolder}/`, (error, files) => {
                if (error) return console.error(`Erro ao ler a pasta de comandos ${subfolder}:`, error);

                files.forEach(file => {
                    if (!file.endsWith('.js')) return; // Ignora arquivos que não são JS

                    const command = require(`../commands/${subfolder}/${file}`);
                    if (!command.name) return; // Ignora comandos sem nome

                    // Verifica se o comando já foi adicionado
                    if (client.slashCommands.has(command.name)) {
                        console.log(`Comando duplicado ignorado: ${command.name}`);
                        return;
                    }

                    // Adiciona o comando ao cliente e ao array
                    client.slashCommands.set(command.name, command);
                    SlashsArray.push(command);
                });
            });
        });
    });

    client.on("ready", async () => {
        try {
            // Registro global de comandos
            await client.application.commands.set(SlashsArray);
            console.log("Comandos registrados globalmente.");

            const url = 'https://discord.com/api/v10/applications/@me';
            const data = {
                description: "ALKA STORE - https://discord.gg/jekyMXaTHh",
            };

            // Atualiza a descrição do bot
            await axios.patch(url, data, {
                headers: {
                    Authorization: `Bot ${client.token}`,
                    'Content-Type': 'application/json'
                }
            });

            console.log("Descrição do bot atualizada.");
        } catch (error) {
            console.error("Erro ao registrar comandos ou atualizar descrição:", error);
        }
    });
};